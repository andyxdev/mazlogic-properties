// This file is kept for backward compatibility
// The application now uses the standalone components approach with AppComponent as the bootstrap component
// Configuration is handled in app.config.ts and main.ts

// This file can be safely deleted since we're using standalone components now
export class AppModule {}
